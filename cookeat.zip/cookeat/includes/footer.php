</div>
    </div>
    <footer>
        <p>© 2025 COOKEAT. All Rights Reserved.</p>
    </footer>
    
<script src="assets/js/main.js"></script>
</body>
</html>