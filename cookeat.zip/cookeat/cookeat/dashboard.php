<?php
session_start();

if (!isset($_SESSION['email'])) {
    header("Location: login.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
    <head>
    </head>
<body>
    <nav class="navbar navbar-expand-sm navbar-light bg-success">
        <div class="container">
            <form class="d-flex my-2 my-lg-0">
                <a href="./logout.php" class="btn btn-light my-2 my-sm-0"
                    type="submit" style="font-weight:bolder;color:green;">
                    logout</a>
            </form>
        </div>
    </nav>

    <div>
        <h2>Welcome To Dashboard</h2>
    </div>
</body>

</html>
