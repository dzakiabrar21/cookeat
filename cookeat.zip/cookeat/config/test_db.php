<?php
    include 'db.php';
    echo "Koneksi berhasil!";
?>