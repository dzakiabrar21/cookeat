<?php
include 'includes/header.php';
?>
<style>
    .container{
        display:flex;
        flex-direction: column;
        height:90vh;
        justify-content: center;
        align-items: center; 
        background-position: center;
    }
    .coba img {
        width: 88%;
        aspect-ratio: 4 / 4;
        /* height: auto;  */
        background-image:url("assets/uploads/cookie.jpg");
    }
    .coba {
        width:95%;
        display: flex;
        background-color:rgb(148, 113, 86);
        align-items: center;
        justify-content: center; 
        aspect-ratio: 4 / 4;
    }
    h2{
        color:rgba(196, 150, 114, 0.78);
    }
    h1{
        color: #744928;
        font-size:60px;
    }
</style>
<h1><strong>COOKEAT</strong></h1>
<h2><strong>Cook it & Eat it</strong></h2>
<div class="coba rounded-circle">
    <!-- <div class="rounded-circle">
    </div> -->
    <img src="assets/uploads/cookie.jpg" class="rounded-circle" alt="Example" draggable="false">
</div>
<?php
include 'includes/footer.php';
?>